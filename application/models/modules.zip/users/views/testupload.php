<form action="<?php echo base_url();?>users/upload" method='post' enctype="multipart/form-data">
<h3>Upload image file here</h3><br/>
<div style='margin:10px'>
<input type='file' name='file'/> 
<input type='submit' value='Upload Image'/>
</div>
</form>